const express = require('express');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname)));


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/log', async (req, res) => {
    try {
        
        const newEntry = {
            IPAddrClient: req.ip,
            port: req.socket.remotePort,
            Time: new Date().toLocaleString('uk-UA', { 
                day: '2-digit', 
                month: '2-digit', 
                year: 'numeric', 
                hour: '2-digit', 
                minute: '2-digit'
            }).replace(',', '')
        };

        
        let data = {};
        try {
            const fileContent = await fs.readFile('client.json', 'utf-8');
            data = JSON.parse(fileContent);
        } catch (error) {
           
        }

        const entryNumber = Object.keys(data).length + 1;       
        data[entryNumber.toString()] = newEntry;
        await fs.writeFile('client.json', JSON.stringify(data, null, 2));

        
        res.redirect('/');
    } catch (error) {
        console.error('Помилка:', error);
        res.status(500).send('Помилка сервера');
    }
});


app.listen(PORT, () => {
    console.log(`Сервер запущено на http://localhost:${PORT}`);
});