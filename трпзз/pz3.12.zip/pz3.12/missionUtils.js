function calculateAmmoNeeded(soldiers, roundsPerSoldier){
    return soldiers*roundsPerSoldier;
}

function isMissionReady(ammoAvailable, ammoNeeded){
    if (ammoAvailable>=ammoNeeded){
        return true;
    }
    else
    return false;
}

function calculateAmmoReserve(soldiers, roundsPerSoldier, reservePercentage) {
    const baseAmmo = calculateAmmoNeeded(soldiers, roundsPerSoldier);
    const reserve = Math.ceil(baseAmmo * (reservePercentage / 100));
    return baseAmmo + reserve;
}


module.exports = { calculateAmmoNeeded, isMissionReady,calculateAmmoReserve };