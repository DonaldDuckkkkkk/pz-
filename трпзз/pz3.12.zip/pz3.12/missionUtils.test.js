const assert = require('chai').assert;
const { calculateAmmoNeeded, isMissionReady,calculateAmmoReserve } = require('./missionUtils');

describe('missionUtils', function() {
    it('should calculate ammo needed correctly', function() {
        assert.equal(calculateAmmoNeeded(10, 30), 300); // 10 soldiers * 30 rounds = 300
    });

    it('should return true if mission is ready', function() {
        assert.isTrue(isMissionReady(500, 300)); // 500 >= 300
    });

    it('should return false if mission is not ready', function() {
        assert.isFalse(isMissionReady(200, 300)); // 200 < 300
    });
    it('повинен правильно розрахувати резерв боєприпасів (50%)', function() {
        assert.equal(calculateAmmoReserve(5, 20, 50), 150); // 100 + 50% = 150
    });
});