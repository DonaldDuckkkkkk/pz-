// let a = 0;
// while(a <= 100){
//     console.log(a);
//     a++;
// }



// let a = 0;
// do{
//     if(a === 0){
//         console.log(`${a} - це нуль`);
//     }
//     else if(a % 2 === 0){
//         console.log(`${a} - парне число`);
//     }
//     else{
//         console.log(`${a} - непарне число`);
//     }
//     a++;
// }while(a <= 10);




// let a = 0;
// for(a; a <=10; console.log(a++)){};







// let numb = 10000;
// let result = numb;
// let counter = 0;

// while (result >= 50) {
//   result = result / 2;
//   counter++;
// }

// console.log("Передостаннє число більше за 50: " + result * 2); // Попереднє перед тим, як число стало меншим за 50
// console.log("Кількість ітерацій: " + counter);




