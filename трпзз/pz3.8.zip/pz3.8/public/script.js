// Перевірка автентифікації при завантаженні сторінки
async function checkAuth() {
  const response = await fetch('/auth/current-user');
  if (!response.ok) {
    window.location.href = '/login.html';
    return false;
  }
  const data = await response.json();
  const userInfo = document.getElementById('userInfo');
  userInfo.textContent = `Авторизований користувач: ${data.user.username}`;
  return true;
}

// Функція для завантаження списку транспортних засобів
async function loadVehicles() {
  const response = await fetch('/api/vehicles');
  if (!response.ok) {
    window.location.href = '/login.html';
    return;
  }
  const vehicles = await response.json();
  const vehicleList = document.getElementById('vehicleList');
  vehicleList.innerHTML = '';

  vehicles.forEach(vehicle => {
    const vehicleItem = document.createElement('div');
    vehicleItem.className = 'vehicle-item';
    vehicleItem.innerHTML = `
      <span>ID: ${vehicle._id}, Назва: ${vehicle.name}, Тип: ${vehicle.type}</span>
      <button onclick="deleteVehicle('${vehicle._id}')">Видалити</button>
    `;
    vehicleList.appendChild(vehicleItem);
  });
}
// Пошук транспортного засобу за ID
document.getElementById('getVehicleForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('getVehicleId').value;
  const resultDiv = document.getElementById('singleVehicleResult');
  resultDiv.innerHTML = '';

  try {
    const response = await fetch(`/api/vehicles/${id}`);
    if (!response.ok) throw new Error('Транспортний засіб не знайдено');

    const vehicle = await response.json();
    resultDiv.innerHTML = `
      <div class="vehicle-item">
        <strong>Результат:</strong><br>
        ID: ${vehicle._id}<br>
        Назва: ${vehicle.name}<br>
        Тип: ${vehicle.type}
      </div>
    `;
  } catch (err) {
    resultDiv.innerHTML = `<span style="color: red;">Помилка: ${err.message}</span>`;
  }
});


// Додавання нового транспортного засобу
document.getElementById('createVehicleForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = document.getElementById('createVehicleName').value;
  const type = document.getElementById('createVehicleType').value;

  const response = await fetch('/api/vehicles', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, type }),
  });

  if (!response.ok) {
    window.location.href = '/login.html';
    return;
  }

  document.getElementById('createVehicleForm').reset();
  loadVehicles();
});

// Оновлення транспортного засобу
document.getElementById('updateVehicleForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('updateVehicleId').value;
  const name = document.getElementById('updateVehicleName').value;
  const type = document.getElementById('updateVehicleType').value;

  const updatedData = {};
  if (name) updatedData.name = name;
  if (type) updatedData.type = type;

  const response = await fetch(`/api/vehicles/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updatedData),
  });

  if (!response.ok) {
    window.location.href = '/login.html';
    return;
  }

  document.getElementById('updateVehicleForm').reset();
  loadVehicles();
});

// Видалення транспортного засобу
async function deleteVehicle(id) {
  const response = await fetch(`/api/vehicles/${id}`, { method: 'DELETE' });
  if (!response.ok) {
    window.location.href = '/login.html';
    return;
  }
  loadVehicles();
}

// Вихід із системи
document.getElementById('logoutButton').addEventListener('click', async () => {
  const response = await fetch('/auth/logout', { method: 'POST' });
  if (response.ok) {
    window.location.href = '/login.html';
  }
});

// Завантаження даних при завантаженні сторінки
checkAuth().then(() => {
  loadVehicles();
});