const Vehicle = require('../models/Vehicle');

exports.getAllVehicles = async (req, res) => {
  try {
    const vehicles = await Vehicle.find();
    res.json(vehicles);
  } catch (err) {
    res.status(500).json({ message: 'Помилка сервера', error: err.message });
  }
};

exports.getVehicleById = async (req, res) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    if (!vehicle) return res.status(404).json({ message: 'Транспортний засіб не знайдено' });
    res.json(vehicle);
  } catch (err) {
    res.status(500).json({ message: 'Помилка сервера', error: err.message });
  }
};

exports.createVehicle = async (req, res) => {
  try {
    const { name, type } = req.body;
    const vehicle = new Vehicle({ name, type });
    await vehicle.save();
    res.status(201).json(vehicle);
  } catch (err) {
    res.status(400).json({ message: 'Невірні дані', error: err.message });
  }
};

exports.updateVehicle = async (req, res) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    if (!vehicle) return res.status(404).json({ message: 'Транспортний засіб не знайдено' });

    vehicle.name = req.body.name || vehicle.name;
    vehicle.type = req.body.type || vehicle.type;
    await vehicle.save();

    res.json(vehicle);
  } catch (err) {
    res.status(400).json({ message: 'Невірні дані', error: err.message });
  }
};

exports.deleteVehicle = async (req, res) => {
  try {
    const vehicle = await Vehicle.findByIdAndDelete(req.params.id);
    if (!vehicle) return res.status(404).json({ message: 'Транспортний засіб не знайдено' });
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ message: 'Помилка сервера', error: err.message });
  }
};