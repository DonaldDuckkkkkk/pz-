const passport = require('passport');

exports.login = (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);
    if (!user) return res.status(401).json({ message: info.message });
    req.logIn(user, (err) => {
      if (err) return next(err);
      res.json({ message: 'Успішний вхід', user: { id: user._id, username: user.username } });
    });
  })(req, res, next);
};

exports.logout = (req, res) => {
  req.logout((err) => {
    if (err) return res.status(500).json({ message: 'Помилка при виході' });
    res.json({ message: 'Успішний вихід' });
  });
};

exports.getCurrentUser = (req, res) => {
  if (req.isAuthenticated()) {
    res.json({ user: { id: req.user._id, username: req.user.username } });
  } else {
    res.status(401).json({ message: 'Користувач не автентифікований' });
  }
};