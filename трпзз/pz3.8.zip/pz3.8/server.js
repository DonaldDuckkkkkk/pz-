const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const session = require('express-session');
const passport = require('passport');
const app = express();

console.log('Сервер починає запуск...');

// Налаштування Express
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
console.log('Express налаштовано');

// Налаштування сесій
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Для localhost
}));
console.log('Сесії налаштовано');

// Ініціалізація Passport
app.use(passport.initialize());
app.use(passport.session());
console.log('Passport ініціалізовано');

// Підключення до MongoDB
mongoose.connect('mongodb://localhost:27017/vehicle')
  .then(() => console.log('Підключено до MongoDB'))
  .catch(err => {
    console.error('Помилка підключення до MongoDB:', err);
    process.exit(1);
  });

// Налаштування Passport
const User = require('./models/User');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');

passport.use(new LocalStrategy(
  async (username, password, done) => {
    console.log(`Спроба автентифікації для користувача: ${username}`);
    try {
      const user = await User.findOne({ username });
      if (!user) {
        console.log('Користувача не знайдено');
        return done(null, false, { message: 'Невірний логін' });
      }
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        console.log('Невірний пароль');
        return done(null, false, { message: 'Невірний пароль' });
      }
      console.log('Автентифікація успішна');
      return done(null, user);
    } catch (err) {
      console.error('Помилка автентифікації:', err);
      return done(err);
    }
  }
));

passport.serializeUser((user, done) => {
  console.log('Серіалізація користувача:', user.id);
  done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
  console.log('Десеріалізація користувача:', id);
  try {
    const user = await User.findById(id);
    done(null, user);
  } catch (err) {
    console.error('Помилка десеріалізації:', err);
    done(err);
  }
});

// Middleware для перевірки автентифікації
function ensureAuthenticated(req, res, next) {
  console.log('Перевірка автентифікації, автентифікований:', req.isAuthenticated());
  if (req.isAuthenticated()) {
    return next();
  }
  console.log('Перенаправлення на /login.html через відсутність автентифікації');
  res.redirect('/login.html');
}

// Маршрути
const vehicleRoutes = require('./routes/vehicleRoutes');
const authRoutes = require('./routes/authRoutes');

app.use('/api/vehicles', ensureAuthenticated, vehicleRoutes);
app.use('/auth', authRoutes);

// Захищений маршрут для index.html
app.get('/index.html', ensureAuthenticated, (req, res) => {
  console.log('Доступ до index.html, автентифікований:', req.isAuthenticated());
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Кореневий маршрут
app.get('/', (req, res) => {
  console.log('Кореневий маршрут, автентифікований:', req.isAuthenticated());
  if (req.isAuthenticated()) {
    console.log('Перенаправлення на /index.html');
    res.redirect('/index.html');
  } else {
    console.log('Перенаправлення на /login.html');
    res.redirect('/login.html');
  }
});

// Налаштування статичних файлів (після всіх маршрутів)
app.use(express.static(path.join(__dirname, 'public'), { index: false }));
console.log('Статичні файли налаштовано');

// Запуск сервера
app.listen(3000, () => {
  console.log('Сервер запущено на порту 3000');
});

/*// Генерація хешів для кількох паролів
const passwords = ['password123','user1pass','user2pass'];
passwords.forEach(async (password) => {
  const hash = await generateHash(password);
  console.log(`Пароль: ${password}, Хеш: ${hash}`);
});*/