// let plus; 
// let min;
// let sum;
// let riz;
// let a, b;  
// numbers();



// number1();
//number2([144, 165 ,144, 144, 144, 144, 144, 144]); 
//alert(number3([[3, 2, 1], [4, 6, 5], [], [9, 7, 8]])); 
//add(); 
//sub();
//mul();
//div();
//cacl();
//number5();
//alert(number6([1, 2, 2, 4, 5, 4, 7, 8, 7, 3, 6]));
//number8([8,8,8,8,8]);
//number9([1, 2, 3, 4, 5, "Шість", 7, "Вісім", 9, 10]);
//number10();


function number1(){
    let n = prompt("Введіть довжину масиву:");
    n = parseInt(n); 

    if (isNaN(n) || n <= 0 ) {
        alert("Невірне число :D");
        return;
    } 


  
    let mac = Array.from({ length: n }, (_, i) => i + 1).reverse();

    console.log(`Довжина: ${n} ==>[ ${mac} ]`);
    alert("Згенерований масив в консолі ");
}


function number2(mac) {
    let num = mac.find(num => mac.indexOf(num) === mac.lastIndexOf(num));
    if (num==null){
     alert("Немає числа");
    }
    console.log("Масив ==>", mac,  "Число ==>:", num);
    return num;
}

function number3(mac) {

    return mac.flat().sort((a, b) => a - b);

}




function numbers() {
    a = prompt("Введіть перше число:");
    a = parseInt(a);

    if (isNaN(a)) {
        alert("Невірне число :D");
        return;
    }

    b = prompt("Введіть друге число:");
    b = parseInt(b);

    if (isNaN(b)) {
        alert("Невірне число :D");
        return;
    }

    plus = a + b; 
    min = a-b;
    sum = a*b;
    riz = a/b;
}

function add() {

        alert(`${a} + ${b} = ${plus}`);
}
function sub(){
    alert(`${a} - ${b} = ${min}`);
}
function mul(){
    alert(`${a} * ${b} = ${sum}`);
}
function div(){
    if(a <= 0 && b <= 0){
        alert("Error :D ");
        return;
    }
    alert(`${a} / ${b} = ${riz}`);
}


function cacl() {
    let diy = prompt("Введіть бажану операцію (+, -, *, /):");
    switch (diy) {
        case "+":
            add();
            break;
        case "-":
            sub();
            break;
        case "*":
            mul();
            break;
        case "/":
            div();
            break;
        default:
            alert("Немає такої операції");
    }
}

function number5() {
    let a = prompt("Введіть число:");
    a = parseInt(a);

    if (isNaN(a)) {
        alert("Невірне число :D");
        return; 
    }

    //позитивне\негативне число
    if (a > 0) {
        alert("Число позитивне");
    }
    else if (a === 0) {
        alert("Нуль");
    }
    else {
        alert("Число негативне");
    }

    //просте\непросте число
    if (a <= 1) {
        alert("Число не є простим");
    } 
    else if (a === 2) {
        alert("Просте число");
    }
    else if (a % 2 === 0) {
        alert("Число не є простим");
    }
    else {
        let isPrime = true;
        for (let i = 3; i <= Math.sqrt(a); i += 2) { 
            if (a % i === 0) {
                isPrime = false;
                break;
            }
        }

        if (isPrime) {
            alert("Просте число");
        } else {
            alert("Непросте число");
        }
    }
    //ділення на 2,5,3,6,9
    let txt = "";

if (a % 2 === 0) {txt += "Число ділиться на 2\n"} else {txt += "Число не ділиться на 2\n"};
if (a % 5 === 0) {txt += "Число ділиться на 5\n";} else {txt += "Число не ділиться на 5\n"};
if (a % 3 === 0) {txt += "Число ділиться на 3\n"} else {txt += "Число не ділиться на 3\n"};
if (a % 6 === 0) {txt += "Число ділиться на 6\n"} else {txt += "Число не ділиться на 6\n"};
if (a % 9 === 0) {txt += "Число ділиться на 9\n"} else {txt += "Число не ділиться на 9\n"};


if (txt) {
    
    alert(txt);
} 
else { 
    alert("Число не ділиться на 2, 5, 3, 6, 9");
}


}


function number8(arr) {
    

    let sum = arr.reduce((acc, num) => acc + num, 0); 
    let serA = sum / arr.length; 

    alert("Середнє арифметичне: " +"["+ serA +"]");
}


function number9(mac){
   
    let arr = mac.map(function(element) {
        if (typeof element === 'number') 
            {
            return Math.pow(element);  //** 2 замість Math.pow
        } else {
            return element;
        }
    }).reverse();
alert(arr);
}

function number10() {
    let side = prompt("Введіть довжину сторони:");
    let count = prompt("Введіть кількість сторін:");

    if (isNaN(side) || isNaN(count) || side <= 0 || count <= 0) {
        alert("Невірне число :D");
        return;
    }
    else {
       
        alert(`Периметр=${side * count}`);
    }
}





















 