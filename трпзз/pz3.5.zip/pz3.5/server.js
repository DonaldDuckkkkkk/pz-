import { MongoClient } from "mongodb";
import readlineSync from "readline-sync";

const uri = "mongodb://127.0.0.1:27017";
const dbName = "unit";
const collectionName = "military_unit";

let client;

async function connectToMongoDB() {
    try {
        client = await MongoClient.connect(uri);
        console.log("Підключено до MongoDB");

        const db = client.db(dbName);
        const collections = await db.listCollections({ name: collectionName }).toArray();
        if (collections.length === 0) {
            await db.createCollection(collectionName);
            console.log(`Колекцію "${collectionName}" створено`);
        } else {
            console.log(`Колекція "${collectionName}" вже існує`);
        }
        return db.collection(collectionName);
    } catch (error) {
        console.error("Помилка підключення до MongoDB:", error);
        throw error;
    }
}
async function displayAllPersonnel(collection) {
    console.log("\n=== Список особового складу ===");
    const personnel = await collection.find({}).toArray();
    personnel.forEach(person => {
        console.log(`ID: ${person._id}, Ім'я: ${person.name}, Звання: ${person.rank}, Підрозділ: ${person.unit}`);
    });
    console.log("================================\n");
}
async function addPersonnel(collection) {
    try {
        const name = readlineSync.question("Введіть ім'я: ");
        const rank = readlineSync.question("Введіть звання: ");
        const unit = readlineSync.question("Введіть підрозділ: ");
        const position = readlineSync.question("Введіть посаду: ");
        const status = readlineSync.question("Введіть статус (наприклад, 'Активний', 'У відпустці'): ");

        if (!name || !rank || !unit || !position || !status) {
            console.log("Усі поля обов'язкові!\n");
            return;
        }

        const newPerson = {
            name,
            rank,
            unit,
            position,
            status,
        };

        const insertResult = await collection.insertOne(newPerson);
        console.log(`Військовослужбовця ${name} успішно додано! (ID: ${insertResult.insertedId})\n`);
    } catch (error) {
        console.error("Помилка при додаванні військовослужбовця:", error);
    }
}

async function displayPersonnelDetails(collection){
    const name = readlineSync.question("Введіть ім'я військовослужбовця: ");
    const person = await collection.findOne({ name });
    if (person) {
        console.log("\n=== Детальна інформація ===");
        console.log(person);
        console.log("============================\n");
    } else {
        console.log(`Військовослужбовця з ім'ям ${name} не знайдено.\n`);
    }
}

async function deletePersonnel(collection){
    const name = readlineSync.question("Введіть ім'я військовослужбовця: ");
    const person = await collection.deleteOne({ name });
    if (person.deletedCount > 0) {
        console.log(`Військовослужбовця ${name} успішно видалено.\n`);
    } else {
        console.log(`Військовослужбовця з ім'ям ${name} не знайдено.\n`);
    }
}

async function updatePersonnel(collection){

    const name = readlineSync.question("Введіть ім'я військовослужбовця для редагування: ");
    const person = await collection.findOne({ name });
    if (!person) {
        console.log(`Військовослужбовця з ім'ям ${name} не знайдено.\n`);
        return;
    }

    console.log("Залиште поле порожнім, якщо не хочете змінювати значення.");
    const newName = readlineSync.question(`Нове ім'я (${person.name}): `) || person.name;
    const newRank = readlineSync.question(`Нове звання (${person.rank}): `) || person.rank;
    const newUnit = readlineSync.question(`Новий підрозділ (${person.unit}): `) || person.unit;
    const newPosition = readlineSync.question(`Нова посада (${person.position}): `) || person.position;
    const newStatus = readlineSync.question(`Новий статус (${person.status}): `) || person.status;

    await collection.updateOne(
        { name },
        { $set: { name: newName, rank: newRank, unit: newUnit, position: newPosition, status: newStatus } }
    );
    console.log(`Дані про військовослужбовця ${name} успішно оновлено!\n`);
}


async function mainMenu() {
    const collection = await connectToMongoDB();
    try {
        while (true) {
            console.log("=== Система обліку особового складу ===");
            console.log("1. Вивести весь особовий склад");
            console.log("2. Додати нового військовослужбовця");
            console.log("3. Вивести детальну інформацію про військовослужбовця");
            console.log("4. Видалити військовослужбовця");
            console.log("5. Редагувати дані про військовослужбовця");
            console.log("7. Вийти");
            const choice = readlineSync.question("Оберіть опцію (1-7): ");

            if (choice === "1") {
                await displayAllPersonnel(collection);
            } else if (choice === "2") {
                await addPersonnel(collection);
            } else if (choice === "3") {
                await displayPersonnelDetails(collection);
            } else if (choice === "4") {
                await deletePersonnel(collection);
            } else if (choice === "5") {
                await updatePersonnel(collection);
            } else if (choice === "7") {
                console.log("Програма завершена.");
                break;
            } else {
                console.log("Невірний вибір. Спробуйте ще раз.\n");
            }
        }
    } catch (error) {
        console.error("Помилка:", error);
    } finally {
        if (client) {
            await client.close();
            console.log("З'єднання з MongoDB закрито");
        }
    }
}

mainMenu().catch(console.error);