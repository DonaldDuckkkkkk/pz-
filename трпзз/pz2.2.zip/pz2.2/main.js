
let moment = require('moment');
console.log(moment().format('YYYY-MM-DD HH:mm:ss'));

let colors = require('colors');
let path = require('path');
let sound = require("sound-play");
let os = require('os');
let inquirer = require('inquirer');
let readline = require('readline');


let soundPath = path.join(__dirname, 'sounds', 'sound2.mp3'); 

function printText(){
   
    sound.play(soundPath);

    console.log('OMG Rainbows!'.rainbow);
}

//printText();

async function askForPath() {
    let prompt = inquirer.createPromptModule();
    let answers = await prompt([
      {
        type: 'input',
        name: 'inputText',
        message: 'Введіть абсолютний шлях до файлу:'
      }
    ]);
  
    let inputPath = answers.inputText;
  
    if (!inputPath) {
      console.log('Будь ласка, вкажіть шлях до файлу!');
      return;
    }
  
    let systemFamily = os.platform();
  
    let fullPath = path.resolve(inputPath);
    let fileName = path.basename(inputPath);
    let fileExtension = path.extname(inputPath);
  
    console.log(`Повний шлях: ${fullPath}`);
    console.log(`Назва файлу: ${fileName}`);
    console.log(`Розширення файлу: ${fileExtension}`);
    console.log(`Сімейство операційних систем: ${systemFamily}`);
  }
  
  //askForPath();

  function game(){
    console.log("Введіть число 1 або 2");
    

    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    let ran = Math.floor(Math.random()*2)+1;

    rl.question('',(answers)=>{
      if(answers == ran){
        console.log("Ви виграли ");
      }
      else{
        console.log(`Ви програли - виграшне число було ${ran}`);
      }
      rl.close();

    });

  }
  game();


  