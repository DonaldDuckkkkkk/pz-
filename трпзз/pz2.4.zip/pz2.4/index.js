const fs = require('fs').promises;
const path = require('path');
const readline = require('readline');
const { EventEmitter } = require('events');

const fileManagerEmitter = new EventEmitter();
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const WORKING_DIR = path.join(__dirname, 'file_manager_data');

// Переконуємося, що робоча директорія існує
(async () => {
  try {
    await fs.mkdir(WORKING_DIR, { recursive: true });
  } catch (err) {
    console.error('Помилка створення робочої директорії:', err);
  }
})();

fileManagerEmitter.on('create', async (fileName, isDir = false) => {
  try {
    const fullPath = path.join(WORKING_DIR, fileName);
    if (isDir) {
      await fs.mkdir(fullPath, { recursive: true });
      console.log(`Подія: Каталог "${fileName}" створено успішно`);
    } else {
      await fs.writeFile(fullPath, '');
      console.log(`Подія: Файл "${fileName}" створено успішно`);
    }
  } catch (err) {
    console.error(`Помилка створення ${isDir ? 'каталогу' : 'файлу'}:`, err.message);
  }
  showMenu();
});

fileManagerEmitter.on('read', async (fileName, isDir = false) => {
  try {
    const fullPath = path.join(WORKING_DIR, fileName);
    if (isDir) {
      const files = await fs.readdir(fullPath);
      console.log(`Подія: Вміст каталогу "${fileName}":`, files);
    } else {
      const content = await fs.readFile(fullPath, 'utf8');
      console.log(`Подія: Вміст файлу "${fileName}":`, content);
    }
  } catch (err) {
    console.error(`Помилка читання ${isDir ? 'каталогу' : 'файлу'}:`, err.message);
  }
  showMenu();
});

fileManagerEmitter.on('update', async ({ fileName, content, newName, isDir = false }) => {
  try {
    const fullPath = path.join(WORKING_DIR, fileName);
    if (newName) {
      const newPath = path.join(WORKING_DIR, newName);
      await fs.rename(fullPath, newPath);
      console.log(`Подія: ${isDir ? 'Каталог' : 'Файл'} "${fileName}" перейменовано на "${newName}"`);
    } else if (content !== undefined) {
      await fs.appendFile(fullPath, content + '\n');
      console.log(`Подія: Текст додано до файлу "${fileName}"`);
    }
  } catch (err) {
    console.error(`Помилка оновлення ${isDir ? 'каталогу' : 'файлу'}:`, err.message);
  }
  showMenu();
});

fileManagerEmitter.on('delete', async (fileName, isDir = false) => {
  try {
    const fullPath = path.join(WORKING_DIR, fileName);
    if (isDir) {
      await fs.rm(fullPath, { recursive: true, force: true });
      console.log(`Подія: Каталог "${fileName}" видалено успішно`);
    } else {
      await fs.unlink(fullPath);
      console.log(`Подія: Файл "${fileName}" видалено успішно`);
    }
  } catch (err) {
    console.error(`Помилка видалення ${isDir ? 'каталогу' : 'файлу'}:`, err.message);
  }
  showMenu();
});

// Функція для відображення меню
function showMenu() {
  console.log('\n> Виберіть дію:');
  console.log('1 - Створити файл');
  console.log('2 - Створити каталог');
  console.log('3 - Читати файл');
  console.log('4 - Читати каталог');
  console.log('5 - Оновити файл (додати текст)');
  console.log('6 - Перейменувати файл/каталог');
  console.log('7 - Видалити файл');
  console.log('8 - Видалити каталог');
  console.log('9 - Вийти');
  rl.question('> Введіть номер дії: ', handleUserInput);
}

// Обробка введення користувача
async function handleUserInput(input) {
  const action = parseInt(input);

  switch (action) {
    case 1: // Створити файл
      rl.question('> Введіть назву файлу: ', (fileName) => {
        fileManagerEmitter.emit('create', fileName);
      });
      break;

    case 2: // Створити каталог
      rl.question('> Введіть назву каталогу: ', (dirName) => {
        fileManagerEmitter.emit('create', dirName, true);
      });
      break;

    case 3: // Читати файл
      rl.question('> Введіть назву файлу: ', (fileName) => {
        fileManagerEmitter.emit('read', fileName);
      });
      break;

    case 4: // Читати каталог
      rl.question('> Введіть назву каталогу: ', (dirName) => {
        fileManagerEmitter.emit('read', dirName, true);
      });
      break;

    case 5: // Оновити файл (додати текст)
      rl.question('> Введіть назву файлу: ', (fileName) => {
        rl.question('> Введіть текст для додавання: ', (content) => {
          fileManagerEmitter.emit('update', { fileName, content });
        });
      });
      break;

    case 6: // Перейменувати файл/каталог
      rl.question('> Введіть поточну назву: ', (fileName) => {
        rl.question('> Введіть нову назву: ', (newName) => {
          fileManagerEmitter.emit('update', { fileName, newName });
        });
      });
      break;

    case 7: // Видалити файл
      rl.question('> Введіть назву файлу: ', (fileName) => {
        fileManagerEmitter.emit('delete', fileName);
      });
      break;

    case 8: // Видалити каталог
      rl.question('> Введіть назву каталогу: ', (dirName) => {
        fileManagerEmitter.emit('delete', dirName, true);
      });
      break;

    case 9: // Вийти
      console.log('Програма завершена.');
      rl.close();
      process.exit(0);

    default:
      console.log('Невірний вибір. Спробуйте ще раз.');
      showMenu();
  }
}

// Запуск програми
console.log('Ласкаво просимо до Файлового менеджера!');
showMenu();